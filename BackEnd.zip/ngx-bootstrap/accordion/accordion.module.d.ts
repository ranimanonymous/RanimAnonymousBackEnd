import { ModuleWithProviders } from '@angular/core';
export declare class AccordionModule {
    static forRoot(): ModuleWithProviders;
}
