/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// place in new Date([array])
/** @type {?} */
export const YEAR = 0;
/** @type {?} */
export const MONTH = 1;
/** @type {?} */
export const DATE = 2;
/** @type {?} */
export const HOUR = 3;
/** @type {?} */
export const MINUTE = 4;
/** @type {?} */
export const SECOND = 5;
/** @type {?} */
export const MILLISECOND = 6;
/** @type {?} */
export const WEEK = 7;
/** @type {?} */
export const WEEKDAY = 8;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uc3RhbnRzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vbmd4LWJvb3RzdHJhcC9jaHJvbm9zLyIsInNvdXJjZXMiOlsidW5pdHMvY29uc3RhbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUNBLE1BQU0sT0FBTyxJQUFJLEdBQUcsQ0FBQzs7QUFDckIsTUFBTSxPQUFPLEtBQUssR0FBRyxDQUFDOztBQUN0QixNQUFNLE9BQU8sSUFBSSxHQUFHLENBQUM7O0FBQ3JCLE1BQU0sT0FBTyxJQUFJLEdBQUcsQ0FBQzs7QUFDckIsTUFBTSxPQUFPLE1BQU0sR0FBRyxDQUFDOztBQUN2QixNQUFNLE9BQU8sTUFBTSxHQUFHLENBQUM7O0FBQ3ZCLE1BQU0sT0FBTyxXQUFXLEdBQUcsQ0FBQzs7QUFDNUIsTUFBTSxPQUFPLElBQUksR0FBRyxDQUFDOztBQUNyQixNQUFNLE9BQU8sT0FBTyxHQUFHLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBwbGFjZSBpbiBuZXcgRGF0ZShbYXJyYXldKVxuZXhwb3J0IGNvbnN0IFlFQVIgPSAwO1xuZXhwb3J0IGNvbnN0IE1PTlRIID0gMTtcbmV4cG9ydCBjb25zdCBEQVRFID0gMjtcbmV4cG9ydCBjb25zdCBIT1VSID0gMztcbmV4cG9ydCBjb25zdCBNSU5VVEUgPSA0O1xuZXhwb3J0IGNvbnN0IFNFQ09ORCA9IDU7XG5leHBvcnQgY29uc3QgTUlMTElTRUNPTkQgPSA2O1xuZXhwb3J0IGNvbnN0IFdFRUsgPSA3O1xuZXhwb3J0IGNvbnN0IFdFRUtEQVkgPSA4O1xuIl19