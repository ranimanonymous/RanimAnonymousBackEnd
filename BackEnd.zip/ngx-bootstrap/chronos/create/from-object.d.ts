import { DateParsingConfig } from './parsing.types';
export declare function configFromObject(config: DateParsingConfig): DateParsingConfig;
