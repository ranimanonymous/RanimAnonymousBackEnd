import { DateParsingConfig } from './parsing.types';
export declare function configFromArray(config: DateParsingConfig): DateParsingConfig;
