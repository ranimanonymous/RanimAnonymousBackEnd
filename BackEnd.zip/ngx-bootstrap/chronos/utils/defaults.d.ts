export declare function defaults<T>(a?: T, b?: T, c?: T): T;
