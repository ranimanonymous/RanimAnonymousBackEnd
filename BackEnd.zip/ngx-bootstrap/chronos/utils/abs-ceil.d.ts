export declare function absCeil(number: number): number;
