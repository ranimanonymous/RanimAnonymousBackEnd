export declare function initTimezone(): void;
export declare function getZoneAbbr(isUTC: boolean): "" | "UTC";
export declare function getZoneName(isUTC: boolean): "" | "Coordinated Universal Time";
