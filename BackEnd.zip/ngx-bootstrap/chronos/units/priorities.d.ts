export declare function addUnitPriority(unit: string, priority: number): void;
