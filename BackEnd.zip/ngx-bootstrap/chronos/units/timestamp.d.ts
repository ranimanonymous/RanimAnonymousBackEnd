export declare function initTimestamp(): void;
