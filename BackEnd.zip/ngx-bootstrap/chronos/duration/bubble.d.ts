import { Duration } from './constructor';
export declare function bubble(dur: Duration): Duration;
export declare function daysToMonths(day: number): number;
export declare function monthsToDays(month: number): number;
