import { AnimationMetadata } from '@angular/animations';
export declare const COLLAPSE_ANIMATION_TIMING = "400ms cubic-bezier(0.4,0.0,0.2,1)";
export declare const expandAnimation: AnimationMetadata[];
export declare const collapseAnimation: AnimationMetadata[];
